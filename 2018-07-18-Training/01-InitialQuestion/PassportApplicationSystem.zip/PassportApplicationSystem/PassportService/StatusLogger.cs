﻿using System;
using System.Collections.Generic;
using PassportServiceSystem.Models;

namespace PassportServiceSystem
{
    public class StatusLogger
    {
        public void LogError(ApplicationForm applicationForm, List<string> errorMessages)
        {
            Display("Sorry! ", ConsoleColor.Cyan);
            Display("Application could not be processed ");
            Display(applicationForm.FirstName + " " + applicationForm.SurName, ConsoleColor.Yellow);
            Console.WriteLine();

            Console.ForegroundColor = ConsoleColor.Red;
            errorMessages.ForEach(x => Console.WriteLine("\t" + x));
            Console.ResetColor();
            Console.WriteLine("");
        }

        public void LogSuccess(ApplicationForm applicationForm)
        {
            Display("Congratulations! ", ConsoleColor.Yellow);
            Display("Application has been processed for ");
            Display(applicationForm.FirstName+ " "+applicationForm.SurName, ConsoleColor.Yellow);
            Console.WriteLine();
            Console.WriteLine("");
        }

        private void Display(string message, ConsoleColor consoleColor = ConsoleColor.White)
        {
            Console.ForegroundColor = consoleColor;
            Console.Write(message);
            Console.ResetColor();
        }
    }
}
