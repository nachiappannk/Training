﻿using PassportServiceSystem.Models;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace PassportServiceSystem
{
    public class FileReader
    {
        public List<ApplicationForm> GetApplicationForms(string filePath)
        {
            var lines = File.ReadLines(filePath);
            var applicationForms = new List<ApplicationForm>();

            lines.ToList().ForEach(line =>
            {
                var formInfo = line.Split(',');
                applicationForms.Add(new ApplicationForm
                {
                    FirstName = formInfo[0] ?? string.Empty,
                    SurName = formInfo[1] ?? string.Empty,
                    EmailId = formInfo[2] ?? string.Empty,
                    Phone = formInfo[3] ?? string.Empty,
                });
            });

            return applicationForms;
        }
    }
}
