﻿using System;
using System.IO;

namespace PassportServiceSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            var filePath = args[0];
            if (!File.Exists(filePath))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Oops!, invalid file path. Please try again");
                Console.ResetColor();
                return;
            }

            var applicationForms = new FileReader().GetApplicationForms(filePath);
            if (applicationForms == null || applicationForms.Count == 0)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Oops!, There is no data in the file. Please try again.");
                Console.ResetColor();
                return;
            }

            var passportService = new PassportService(new StatusLogger(),
                new PassportStatusChecker(), new PassportApplicationProcessor());

            applicationForms.ForEach(applicationForm =>
            {
                passportService.ProcessApplication(applicationForm);
            });
            Console.ReadLine();
        }
    }
}
