﻿using PassportServiceSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PassportServiceSystem
{
    public class PassportApplicationProcessor
    {
        private readonly List<ApplicationForm> _appliedApplicationForms;

        public PassportApplicationProcessor()
        {
            _appliedApplicationForms = new List<ApplicationForm>();
        }

        public bool IsApplicationAvailable(string emailId)
        {
            return _appliedApplicationForms.Count(x => x.EmailId.Equals(emailId, StringComparison.InvariantCultureIgnoreCase)) > 0;
        }

        public void ApplyForPassport(ApplicationForm applicationForm)
        {
            _appliedApplicationForms.Add(applicationForm);
        }
    }
}
