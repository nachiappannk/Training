﻿using PassportServiceSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PassportServiceSystem
{
    public class PassportService
    {
        private readonly StatusLogger _statusLogger;
        private readonly PassportStatusChecker _statusChecker;
        private readonly PassportApplicationProcessor _applicationProcessor;

        public PassportService(StatusLogger statusLogger, PassportStatusChecker statusChecker, PassportApplicationProcessor applicationProcessor)
        {
            _statusLogger = statusLogger;
            _statusChecker = statusChecker;
            _applicationProcessor = applicationProcessor;
        }

        public void ProcessApplication(ApplicationForm applicationForm)
        {
            if (_statusChecker.IsPassportIssued(applicationForm.EmailId))
            {
                _statusLogger.LogError(applicationForm, new List<string>() { "Passport already issued." });
                return;
            }

            if (_applicationProcessor.IsApplicationAvailable(applicationForm.EmailId))
            {
                _statusLogger.LogError(applicationForm, new List<string>() { "Your application is in process." });
                return;
            }

            if (string.IsNullOrWhiteSpace(applicationForm.FirstName))
            {
                _statusLogger.LogError(applicationForm, new List<string>() { "First Name is empty" });
                return;
            }

            if (string.IsNullOrWhiteSpace(applicationForm.SurName))
            {
                _statusLogger.LogError(applicationForm, new List<string>() { "Surname is empty" });
                return;
            }

            _applicationProcessor.ApplyForPassport(applicationForm);
            _statusLogger.LogSuccess(applicationForm);
        }
        




    }
}
