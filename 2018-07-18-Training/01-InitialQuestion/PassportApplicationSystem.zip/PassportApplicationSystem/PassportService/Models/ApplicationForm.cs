﻿using System;

namespace PassportServiceSystem.Models
{
    public class ApplicationForm
    {
        public string FirstName { get; set; }

        public string SurName { get; set; }

        public string EmailId { get; set; }

        public string Phone { get; set; }
    }
}
