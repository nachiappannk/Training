﻿using System;
using System.Collections.Generic;
using PassportServiceSystem.Models;
using System.Linq;

namespace PassportServiceSystem
{
    public class PassportStatusChecker
    {
        private readonly List<ApplicationForm> _issuedApplicationForms;

        public PassportStatusChecker()
        {
            _issuedApplicationForms = new List<ApplicationForm>()
            {
                new ApplicationForm()
                {
                    FirstName = "Mr. Roy, Rakesh",
                    EmailId = "rakesh.roy@gmail.com",
                    Phone = "9876543210"
                },

                new ApplicationForm()
                {
                    FirstName = "Mrs. Pushkar, Sunanda",
                    EmailId = "sunanda.pushkar@yahoo.com",
                    Phone = "9988776655"
                },

                new ApplicationForm()
                {
                    FirstName = "Ms. Arora, Nancy",
                    EmailId = "nancy_arora@outlook.com",
                    Phone = "8976543210"
                },

                new ApplicationForm()
                {
                    FirstName = "Dr. Rao, Rajendra",
                    EmailId = "rajendar.rao@rediff.com",
                    Phone = "7894561230"
                },

                new ApplicationForm()
                {
                    FirstName = "Mr. Mallya, Ajay",
                    EmailId = "ajay.mallya@gmail.com",
                    Phone = "8529637410"
                }
            };
        }

        public bool IsPassportIssued(string emailId)
        {
            return _issuedApplicationForms.Count(x => x.EmailId.Equals(emailId, StringComparison.InvariantCultureIgnoreCase)) > 0;
        }
    }
}
